# syracuse-sdata

* [syracuse-sdata/lib/render/pdf](lib/render/pdf.md)  
  Pdf rendering
* [syracuse-sdata/lib/render/stylesheet](lib/render/stylesheet.md)  
  Style sheet management for PDF customization
