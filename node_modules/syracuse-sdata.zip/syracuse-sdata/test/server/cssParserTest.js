"use strict";

var module = QUnit.module;
var fs = require('fs');
var sys = require("util");

var config = require('syracuse-main/lib/nodeconfig').config; // must be first syracuse require
var cssParser = require('syracuse-sdata/lib/render/cssParser');

var tracer = sys.log;

function dump(o) {
	tracer && tracer("" + sys.inspect(o, true, null));
}

//var tracer = null;
module("cssParserTest", {
	setup: function() {},
	teardown: function() {}
});

test("css without comments", 1, function() {
	var css = cssParser.parse('\
section {\
	margin: 5;\
	border: 2 solid gray;\
	border-radius: 3;\
	padding: 5;\
}\
\
section-title {\
	font-family: "Helvetica-Bold";\
	font-size: 12;\
	color: #69923A;\
}\
');
	var expected = {
		section: {
			margin: {
				right: 5,
				left: 5,
				bottom: 5,
				top: 5
			},
			border: {
				right: {
					style: 'solid',
					color: 'gray',
					width: 2
				},
				left: {
					style: 'solid',
					color: 'gray',
					width: 2
				},
				bottom: {
					style: 'solid',
					color: 'gray',
					width: 2
				},
				radius: 3,
				top: {
					style: 'solid',
					color: 'gray',
					width: 2
				}
			},
			padding: {
				right: 5,
				left: 5,
				bottom: 5,
				top: 5
			}
		},
		'section-title': {
			font: {
				family: 'Helvetica-Bold',
				size: 12
			},
			color: '#69923A'
		}
	};
	deepEqual(css, expected, "css objects are equal");
});

test("css with comments", 1, function() {
	var css = cssParser.parse('\
	/* a comment outside a css block */\
	section {\
		margin: 5;\
		border: 2 solid gray;\
		border-radius: 3;\
		padding: 5;\
	}\
	\
	/* a multi line \
	comment outside \
	a css block \
	*/\
	section-title {\
	/* a comment inside a css block */\
		font-family: "Helvetica-Bold";\
		font-size: 12;/* a comment on a css line */\
		/* a multi line \
		comment inside \
		a css block \
		*/\
		color: #69923A;\
	}\
	');

	var expected = {
		section: {
			margin: {
				right: 5,
				left: 5,
				bottom: 5,
				top: 5
			},
			border: {
				right: {
					style: 'solid',
					color: 'gray',
					width: 2
				},
				left: {
					style: 'solid',
					color: 'gray',
					width: 2
				},
				bottom: {
					style: 'solid',
					color: 'gray',
					width: 2
				},
				radius: 3,
				top: {
					style: 'solid',
					color: 'gray',
					width: 2
				}
			},
			padding: {
				right: 5,
				left: 5,
				bottom: 5,
				top: 5
			}
		},
		'section-title': {
			font: {
				family: 'Helvetica-Bold',
				size: 12
			},
			color: '#69923A'
		}
	};
	// dump(css);
	deepEqual(css, expected, "css objects are equal");
});