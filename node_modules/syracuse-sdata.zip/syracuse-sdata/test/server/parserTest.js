var module = QUnit.module;
var parser = require('syracuse-sdata/lib/parser/parser');
var date = require('syracuse-core/lib/types/date')
var datetime = require('syracuse-core/lib/types/datetime')

module("parserTest");

function _testToken(input, val) {
	var exp = parser.Parser.parse(input);
	strictEqual(exp.type, "literal");
	same(exp.value, val, input);
}

test("tokens", 20, function() {
	_testToken("17", 17);
	_testToken("17.0", 17.0);
	_testToken("'GB'", "GB");
	_testToken("\"GB\"", "GB");
	_testToken("\"Maxim's\"", "Maxim's");
	_testToken("'Maxim''s'", "Maxim's");
	_testToken("@2008-05-19@", date.make(2008, 5, 19));
	_testToken("@2008-05-19T18:41:00@", datetime.make(2008, 5, 19, 18, 41, 00));
	_testToken("@2008-05-19T18:41:00+02:00@", datetime.makeUtc(2008, 5, 19, 16, 41, 00));
	_testToken("@2008-05-19T18:41:00Z@", datetime.makeUtc(2008, 5, 19, 18, 41, 00).withoutTimezoneOffset());
});
function _testExpression(input, result) {
	var exp = parser.Parser.parse(input);
	strictEqual(exp.toString(), result, input);
}

test("associativity", 4, function() {
	_testExpression("a.b.c.d", "[. [. [. a b] c] d]");
	_testExpression("a mul b div c div d div e", "[div [div [div [mul a b] c] d] e]");
	// check simple associativity in additive operators
	_testExpression("a+b+c-d+e", "[+ [- [+ [+ a b] c] d] e]");
	// check simple associativity in logical operators
	_testExpression("a and b and c and d", "[and [and [and a b] c] d]");
});
test("precedence", 6, function() {
	// check simple precedence between member access and multiplicative
	_testExpression("a.b mul c.d", "[mul [. a b] [. c d]]");
	// check simple precedence between multiplicative and additive
	_testExpression("a mul b + c div d", "[+ [mul a b] [div c d]]");
	// check simple precedence between multiplicative and additive
	_testExpression("a + b mul c - d", "[- [+ a [mul b c]] d]");
	// check simple precedence between additive and comparison
	_testExpression("a + b lt c - d", "[lt [+ a b] [- c d]]");
	// check simple precedence between comparison and logical
	_testExpression("a lt b and c lt d", "[and [lt a b] [lt c d]]");
	// check simple precedence between logicals
	_testExpression("a and b or c and d", "[or [and a b] [and c d]]");
})
test("misc", 6, function() {
	// check more complex combination involing priorities and associativity
	_testExpression("a.b.c mul d.e.f + g.h.i div j.k.l", "[+ [mul [. [. a b] c] [. [. d e] f]] [div [. [. g h] i] [. [. j k] l]]]");
	// check parentheses override precedence
	_testExpression("(a + b) mul (c + d)", "[mul [+ a b] [+ c d]]");
	// check parentheses override associativity
	_testExpression("a + b - (c + d) + e", "[+ [- [+ a b] [+ c d]] e]");
	// check function syntax
	_testExpression("f() + g(a) + h(b, c, d)", "[+ [+ [f] [g a]] [h b c d]]");
	// check 'in' syntax
	_testExpression("a + b in (c + d, e, f - g)", "[in [+ a b] [+ c d] e [- f g]]");
	// check between syntax
	_testExpression("a + b between c + d and e + f mul g", "[between [+ a b] [+ c d] [+ e [mul f g]]]");

});
function _testSql(input, result) {
	// TODO: context
	var sql = sqlConverter.toSql(context, input);
	strictEqual(sql, result, input);
}

false && test("sql convert", 6, function() {
	// test conversion of arithmetic operators
	_testSql("a mul b + -c div -d - e mod f eq 0", "((((a * b) + ((- c) / (- d))) - (e % f)) = 0)");

	// test conversion of comparison and logical operators
	_testSql("a eq b and c ne d", "((a = b) AND (c <> d))");
	_testSql("a lt b and c le d or e gt f and g ge h", "(((a < b) AND (c <= d)) OR ((e > f) AND (g >= h)))");

	// check conversion of function
	_testSql("substring(a, b, c) eq 'a''bc'", "(SUBSTRING(a, b, c) = 'a''bc')");

	// test conversion of between syntax
	_testSql("a + b between c + d and e + f mul g", "((a + b) BETWEEN (c + d) AND (e + (f * g)))");

	// test in syntax
	_testSql("a + b in (c + d, e, f - g)", "((a + b) IN ((c + d), e, (f - g)))");
});

