"use strict";

var jsxml = require("jsxml/lib/jsxmlold");

function assert(cond, msg) {
                if (!cond) throw new Error(msg);
}

exports.parse = function(str) {
                var root = jsxml.parse(str);
                var sep="";
                assert(root && root.$$tag === 'RP');
                var reply = {
                };
                _rpNode(reply,root);
                _rpChildren(reply,root.$$children);
                
                assert(root.$$children);
                
                function _rpNode(rp,n){
                               for(var key in n){
                                               switch(key){
                                                               case "A"  :{_rpANode(rp,n,key);break;}
                                                               case "C"  :{_rpCNode(rp,n,key);break;}
                                                               case "IB" :{_rpINode(rp,n,key);break;}
                                                               case "IC" :{_rpINode(rp,n,key);break;}
                                                               case "IH" :{_rpINode(rp,n,key);break;}
                                               }
                               }
                };
                function _rpChildren(rp,ns){
                               if(!ns) return
                               ns.forEach(function(c) {
                                               switch(c.$$tag){
                                                               case "ist"  :{_istNode(rp,c);break;}
                                                               case "D"              :{_data(rp,c);break;}
                                                               case "gui"  :{_guimods(rp,c);break;}
                                                               case "R"               :{_rNode(rp,c);break;}
                                                               case "sessionsettings" :{_ssettings(rp,c);break;}
                                                               case "FDS"          :{;break;} //Format
                                                               case "MB"          :{;break;} //menu to append
                                                               case "BS"          :{_bsNode(rp,c);break;} //Ajout menu contextuel (click droit)
                                                               case "SB"          :{_sbNode(rp,c);break;} //SB /SI satus bar + icone
                                                               case "M"             :{_message(rp,c);break;} //info, warning, erreur, progress, etc…)
                                                               case "ENDR" :{;break;}
                                                               case "splash" :{;break;}
                                                               case "months" :{;break;}
                                               }
                               });
                };
                function _rpANode(j,n,k){
                               var s=n[k].split(",");
                               j.srvop=_createIfNotExist(j.srvop);
                               j.srvop.request=_createIfNotExist(j.srvop.request);
                               j.srvop.request.connect=parseInt(s[0],10);
                               j.srvop.request.v=parseInt(s[1],10);
                               j.srvop.request.id=parseInt(s[2],10);
                               j.srvop.request.status=parseInt(s[3],10);s
                };
                function _rpCNode(j,n,k){
                               var xids=_xid(n[k])
                               if (!xids.id) {
                                               return
                               }
                               j.sap=_createIfNotExist(j.sap);
                               j.sap.target=_createIfNotExist(j.sap.target);
                               j.sap.target.typ="ist";
                               j.sap.target.ist=_createIfNotExist(j.sap.target.ist);
                               j.sap.target.ist.xid=xids.id;
                               j.sap.target.ist.win=xids.w
                               if(xids.nl) {
                                               j.sap.target.ist.nl=xids.nl;
                               }
                               j.sap.target.ist.edit=(n.mc!=="1")
                               
                               _setAttribute(j.sap.target.ist,"fmt",n,"IstFmt");
                };
                function _bsNode(j,n){
					var a;
					j.sap=_createIfNotExist(j.sap);
					j.sap.target=_createIfNotExist(j.sap.target);
					j.sap.target.ist=_createIfNotExist(j.sap.target.ist);
					j.sap.target.ist.acts=_creatArray(j.sap.target.ist.acts,-1);
					n.$$children.forEach(function(c){
						a=[];
						a.push(parseInt(c.I,10));
						a.push(c.S==="1");
						if(c.$$value){
							a.push(c.$$value)
						}
						if(c.$$cdata){
							a.push(c.$$cdata)
						}
						j.sap.target.ist.acts.push(a);
					})
                };
				function _sbNode(j,n){
					j.sap=_createIfNotExist(j.sap);
					if(!j.sap.wins){
						j.sap.wins=_createIfNotExist(j.sap.wins);
						j.sap.wins[_winIdCurrent()]=_createIfNotExist(j.sap.wins[_winIdCurrent()])
					}
					var w=j.sap.wins[_winIdCurrent()]
					w.statBar=_createIfNotExist(w.statBar);
					w.statBar.t=[];
					w.statBar.t.push(n.text1);
					w.statBar.t.push(n.text2);
					if(n.$$children){
						n.$$children.forEach(function(c){
							w.statBar.ico=_creatArray(w.statBar.ico,-1)
							w.statBar.ico.push([parseInt(c.I,10),parseInt(c.IC,10)])
						})
					}
                };
                function _xid(k){
                               var x={};
                               var xids=k.split(",");
                               if(xids.length<3) {
                                               return x
                               }
                               if(xids.length>3) {
                                               x.nl=parseInt(xids[3],10);
                                               xids.pop();
                               }
                               x.w=xids[0]
                               xids.shift( )
                               x.id=xids.join(sep);
                               return x
                }
                function _rpINode(j,n,k){
                               var s=n[k].split(","),sts=n["S"+k.substr(1)].split(","),l=s.length;
                               if(l<=1) return
                               j.sap=_createIfNotExist(j.sap);
                               if(j.sap.acts==undefined) j.sap.acts=[];
                               for (var i=1;i<l;i++){
                                               j.sap.acts.push({"id":parseInt(s[i],10),"st":(sts[i]=="1")})
                               }
                };
                function _istNode(j,n){
                               var xids=_xid(n.C)
                               if (!xids.id) {
                                               return
                               }
                               var which=n.which;
                               j.sap=_createIfNotExist(j.sap);
                               j.sap[which]=_createIfNotExist(j.sap[which]);
                               j.sap[which].typ="ist";
                               j.sap[which].ist=_createIfNotExist(j.sap[which].ist)
                               j.sap[which].ist.xid=xids.id;
                               j.sap[which].ist.win=xids.w
                               if(xids.nl){
                                               j.sap[which].ist.nl=xids.nl;
                               }
                               _setAttribute(j.sap[which].ist,"fmt",n,"IstFmt");
                               _setAttribute(j.sap[which].ist,"stat",n,"format");
                               if(n.$$value!=undefined){
                                  j.sap[which].ist.v=n.$$value
                               }
							   if(n.$$cdata!=undefined){
                                     j.sap[which].ist.v=n.$$cdata
                               }
                };
                function _data(rp,n,p){
                               var pr=_prop(n);
                               pr.parent=p;
                               var nn=_setO(rp,pr);
                               if(!n.$$children) return
                               n.$$children.forEach(function(c) {
                                               _data(nn,c,pr)
                               })                            
                };
                function _ssettings(j,n){
							   j.session=_createIfNotExist(j.session);
                               j.session.settings=_createIfNotExist(j.session.settings);
                               n.$$children.forEach(function(c){
								   if(c.$$value){
										j.session.settings[c.$$tag]=c.$$value
									}
									if(c.$$cdata){
										j.session.settings[c.$$tag]=c.$$cdata
									}
                               })
                };
                function _rNode(j,n){
                               var g={},w="";
                               j.sap=_createIfNotExist(j.sap);
                               if(!j.sap.func) {
                                               j.sap.func={};
                               }
                               if(n.O==="1"){
                                               j.sap.func.open=_createIfNotExist(j.sap.func.open);	
											   w= _winIdFromWinNameData(n.W);
											   j.sap.func.open[w]=_createIfNotExist(j.sap.func.open[w]);
									
											   j.sap.func.open[w].name=n.W;
											   j.sap.func.open[w].scrnNum=n.num_screen_to_show;
											   j.sap.func.open[w].model=n.window_model;
											   j.sap.func.open[w].stamp=n.window_stamp;
                                               j.sap.func.open[w].type=n.window_type;
											   j.sap.func.open[w].func=n.function;
											   //g.extend="???";
                                               //j.sap.func.open.push(g);
                               }else{
									//TODO : id pas d'info pour retrouver	
                                               j.sap.func.close=_creatArray(j.sap.func.close,-1);
											   var id=String.fromCharCode(65+parseInt(n.level,10));
                                               j.sap.func.close.push(id);
                               }
                };
                function _prop(rp){
                               var p={}
                               for (var k in rp){
                                               if(k!="$$children"){
                                                               p[k]=rp[k]
                                               }
                               };
                               p.what=_whatData(rp);
                               return p
                };
                function _setO(j,prop){
                               var nn;
                               switch (prop.what){
                                               case "data"        :{nn=_window(j,prop);break;}
                                               case "bloc"         :{nn=_screenBlock(j,prop);break;}
											   case "blocTab"       :{nn=_screenBlockTab(j,prop);break;}
                                               case "record"    :{nn=_record(j,prop);break;}
											   case "recordH"    :{nn=_recordH(j,prop);break;}
                                               case "field"        :{nn=_field(j,prop);break;}
											   case "fieldH"        :{nn=_fieldH(j,prop);break;}
                               }
                               return nn;
                };
                function _setOGui(j,prop){
                               var nn;
                               switch (prop.what){
                                               case "data"        :{nn=_window(j,prop);break;}
                                               case "screen"    :{nn=_screen(j,prop);break;}
                                               case "bloc"         :{nn=_block(j,prop);break;}
											   case "blocTab"       :{nn=_blockTab(j,prop);break;}
                                               case "record"    :{nn=_record(j,prop);break;}
                                               case "field"        :{nn=_field(j,prop);break;}
                               }
                               return nn;
                };
                function _field(j,prop){
                               if(prop.parent.parent.llType || prop.parent.parent.parent.I==="_SCRNLEFT") { //left list
                                               _elementLeftData(j,prop);
                                               return;
                               }
							   //if(prop.parent.I && prop.parent.I=="0") return //grid guimod
                               if(prop.parent.I && prop.parent.parent.parent.$$tag=="scr") { //grid guimod
									//console.log("_field " + JSON.stringify(prop));
									j.$meta=_createIfNotExist(j.$meta)
									if(prop.style || prop.style===""){
										j.$meta.sty=_creatArray(j.$meta.sty,-1)
										j.$meta.sty.push([prop.parent.parent.parent.X+prop.$$tag,parseInt(prop.parent.I,10),prop.style])
									}
									if(prop.s){
										j.$meta.stt=_creatArray(j.$meta.stt,-1)
										j.$meta.stt.push([prop.parent.parent.parent.X+prop.$$tag,parseInt(prop.parent.I,10),prop.s])
									}
									if(prop.t){
										j.$meta.tit=_creatArray(j.$meta.tit,-1)
										j.$meta.tit.push([prop.parent.parent.parent.X+prop.$$tag,parseInt(prop.parent.I,10),prop.t])
									}
                                    return;
                               }
							   if(prop.parent.I ) { 
									_elementDataGrid(j,prop); 
                                    return;
                               }
                               _elementData(j,prop); 
                };
                function _elementLeftData(j,prop){
                               var nn=prop.$$tag;
                               if(nn.indexOf("_")>=0) {
                                               return;
                               }
                               
                               //console.log("_elementLeftData " + JSON.stringify(prop));
                               if(prop.$$value) {
                                               j.push(prop.$$value)
                               }else if(prop.$$cdata){
									j.push(prop.$$cdata)
							   }else{
									   j[nn]=_createIfNotExist(j[nn])
									   _setAttributesGuimod(j[ nn],prop)
                               }
                };
                function _elementData(j,prop){
                               var nn=prop.$$tag,key;
                               if(nn.indexOf("_")>=0) {
                                               return;
                               }
                               if(prop.parent.parent.$$tag==="ds"){
                                               key=prop.parent.parent.I.substr(2,1)+sep+nn
                               }else{
                                               key=prop.parent.parent.$$tag.substr(2,1)+sep+nn
                               }
                               if(prop.$$value) {
									j[key]=_createIfNotExist(j[key])
									j[key].v=prop.$$value
								}
								if(prop.$$cdata) {
									j[key]=_createIfNotExist(j[key])
									j[key].v=prop.$$cdata
								}
                               _setAttributesGuimod(j[key],prop)
                };
				function _elementDataGrid(j,prop){
	                           var nn=prop.$$tag,key;
                               if(nn.indexOf("_")>=0) {
                                               return;
                               }
                               if(prop.parent.parent.$$tag==="ds"){
                                               key=prop.parent.parent.I.substr(2,1)+sep+nn
                               }else{
                                               key=prop.parent.parent.$$tag.substr(2,1)+sep+nn
                               }
							  
							    if(prop.$$value) {
									j[key]=_createIfNotExist(j[key])
									j[key]=prop.$$value
								}else if(prop.$$cdata) {
									j[key]=_createIfNotExist(j[key])
									j[key]=prop.$$cdata
								}
								//console.log("\n_elementDataGrid \n"+  JSON.stringify(prop) + " " + key)							   
                };
                function _record(j,prop){
                               var m=prop.m, nl=prop.I,idx,r;
                               if(!nl){
                                               var p=prop.parent.parent
                                               if(p.what==="screen"){
                                                               p=p.parent;
                                               }
                                               var wi=_window(reply,p)
                                               return wi.entitie;
                               }
                               idx=parseInt(nl,10)-1;
                               if(prop.parent.llType || prop.parent.parent.I==="_SCRNLEFT"){
                                               if(prop.s){
                                                               if(!j.selected){
                                                                              j.selected=[]
                                                               };
                                                               j.selected.push({'nl':nl,"select":((parseInt(prop.s,10) & 16 ) > 0)})
                                               }else{
                                                               if(idx>=0 && prop.parent.llType){
                                                                              j.record=_creatArray(j.record,idx,true);
                                                                              r=j.record[idx];
                                                               }else{
                                                                              if(!j.column){
                                                                                              j.column={}
                                                                              };
                                                                              r=j.column;
                                                               }
                                               }
                               }else if(prop.parent.what=="blocTab"){
									
							   		if(prop.parent.parent.$$tag=="scr"){
										j.$meta=_createIfNotExist(j.$meta)
										if(prop.style){
											j.$meta.sty=_creatArray(j.$meta.sty,-1)
											j.$meta.sty.push([prop.parent.I.substr(2),parseInt(prop.I,10),prop.style])
										}
										if(prop.s){
											j.$meta.stt=_creatArray(j.$meta.stt,-1)
											j.$meta.stt.push([prop.parent.I.substr(2),parseInt(prop.I,10),prop.s])
										}
										if(prop.t){
											j.$meta.tit=_creatArray(j.$meta.tit,-1)
											j.$meta.tit.push([prop.parent.I.substr(2),parseInt(prop.I,10),prop.t])
										}
										r=j
									}else{
										j.push({})	
										r=j[j.length-1];
										r.$i=j.length;
									}
							   }else{
									//console.log("!blocTab",JSON.stringify(prop))
									if(prop.parent.parent.$$tag=="scr"){
										r=j
									}else{							
										   j.record=_creatArray(j.record,idx);
										   r=j.record[idx];
										   _setAttributesGuimod(r,prop);
									}
                               }
                               return r 
                };
				function _recordH(j,prop){
				};
				function _fieldH(j,prop){
				};
                function _screenBlock(j,prop){
					   var nn=prop.$$tag, bn=nn.substr(nn.length-1),scr=nn.substr(2,nn.length-2-bn.length),blk=scr+sep+bn;
					   j.entitie[scr]=_createIfNotExist(j.entitie[scr]);
					   j.entitie[blk]=_createIfNotExist(j.entitie[blk]);
					   if(prop.llType){
									   if(prop.llFormat){
										j.entitie[blk].typ=parseInt(prop.llFormat,10)
									   }else{
										j.entitie[blk].typ=1
									   }
									   j.entitie[blk].left=true;
					   }
					   return j.entitie[blk];                      
                };
				function _screenBlockTab(j,prop){
					   var nn=prop.$$tag, bn=nn.substr(nn.length-1),scr=nn.substr(2,nn.length-2-bn.length),blk=scr+sep+bn;
					   j.entitie[scr]=_createIfNotExist(j.entitie[scr]);
					   j.entitie[blk]=_createIfNotExist(j.entitie[blk])
					   j.entitie[blk].$rcd=_creatArray(j.entitie[blk].$rcd,-1)
					   return j.entitie[blk].$rcd;  
				}
                function _window(j,prop){
                               var c; //i=prop.X.charCodeAt(0)-66
                               j.sap=_createIfNotExist(j.sap);
							   j.sap.wins=_createIfNotExist(j.sap.wins); 
							   j.sap.wins[prop.X]=_createIfNotExist(j.sap.wins[prop.X]);
							   j.sap.wins=_creatArray(j.sap.wins,-1);                    
							   j.sap.wins[prop.X].entitie=_createIfNotExist(j.sap.wins[prop.X].entitie);
                               _setAttributesGuimod(j.sap.wins[prop.X],prop);
                               return j.sap.wins[prop.X];
                };
				function _winIdFromWinNameData(winName){
					var w=null;
					root.$$children.forEach(function(c){
						if(c.$$tag==="D" && c.I===winName){	
							w=c.X 
						}
					})
					return w
				};
				function _winIdCurrent(){
					if(root.C){
						return root.C.split(",")[0]
					}
					return null
				};
                function _whatData(j){
                               if(!j.$$tag) {
                                               return "?"
                               };
                               var l=j.$$tag.length;
                               if(j.$$tag==="r"){
									if(j.$$children && j.$$children[0].$$tag==="n1"){
										return "recordH"
									}else{
                                        return "record"
								    }
                               };
                               if(j.$$tag==="D" || j.$$tag==="gui"){
                                               return "data"
                               };
                               if(l >1 && j.$$tag.substr(0,2)==="ds" ){
													 if(j.RebindCopy){
														return "blocTab"													
													}else if(j.llFormat!="3"){
														return "bloc"
													}else{
														return "bloc"
													}
                               };
                               if(l >2 && j.$$tag==="scr"){
                                               return "screen"
                               }
							   if(j.$$tag==="n1"){
								return "fieldH";
							   }
                               return "field";
                };

                function _guimods(rp,n,p){
                               var pr=_prop(n);
                               pr.parent=p;
                               pr.parent=p;
                               var nn=_setOGui(rp,pr);
                               if(!n.$$children) return
                               n.$$children.forEach(function(c) {
                                               _guimods(nn,c,pr)
                               })
                };
                function _message(rp,n){
                               var typ=parseInt(n.T,10);
                               if(typ <=4){
                                               _infBox(rp,n);
                               }
                };
                function _infBox(rp,n){
                               rp.sap=_createIfNotExist(rp.sap);
                               rp.sap.target=_createIfNotExist(rp.sap.target);
                               rp.sap.target.typ="box";
                               rp.sap.target.box=_createIfNotExist(rp.sap.target.box);
                               rp.sap.target.box.typ=parseInt(n.T);// 0:  MSG_INFBOX, 1:MSG_WARNING , 2:MSG_QUESTION, 3 : MSG_ERROR 4 : MSG_STOP
                               if(n.$$T){
                                     if(n.$$T.$$value) {
										rp.sap.target.box.tit=n.$$T.$$value;
									}
									if(n.$$T.$$cdata){
										rp.sap.target.box.tit=n.$$T.$$cdata;
									}
                               }
                               if(n.appchoix){
                                               rp.sap.target.box.def=n.appchoix;
                               }
                               n.$$children.forEach( function(c){
                                               switch (c.$$tag){
                                                               case "T"  :{if(c.$$value) {
																			rp.sap.target.box.tit=c.$$value
																			}
																			if(c.$$cdata){
																			rp.sap.target.box.tit=c.$$cdata
																			}
																			;break;}
                                                               case "L1" :{rp.sap.target.box.li=[];
																		   if(c.$$value) {
																				rp.sap.target.box.li.push(c.$$value)
																			}
																			if(c.$$cdata){
																				rp.sap.target.box.li.push(c.$$cdata)
																			};break;}
                                                               case "L2" :{if(c.$$value) {
																			rp.sap.target.box.li.push(c.$$value)
																			}
																			if(c.$$cdata){
																				rp.sap.target.box.li.push(c.$$cdata)
																			};break;}
                                               
                                               }
                               
                               }) 
                               
                /*           <M D="0" O="0" T="3" appchoix="3">
                               <T>
                                               <![CDATA[Erreur zone "Code activité"]]>
                               </T>
                               <L1>
                                               <![CDATA[
Codes activité : AZAZA
Fiche inexistante]]>
                               </L1>
                </M>
                */
                
                };
                function _screen(j,prop){
                               j.entitie[prop.X]=_createIfNotExist(j.entitie[prop.X]);
                               _setAttributesGuimod(j.entitie[prop.X],prop);
                               return j.entitie;                               
                };
                function _block(j,prop){
                               var nn=prop.I, bn=nn.substr(nn.length-1),scr=nn.substr(2,nn.length-2-bn.length),blk=scr+sep+bn;
                               j[blk]=_createIfNotExist(j[blk]);
                               if(prop.parent.I==="_SCRNLEFT"){
                                               j[blk].left=true
                               }
                               _setAttributesGuimod(j[blk],prop);
                               return j[blk];                     
                };
				function _blockTab(j,prop){
					   var nn=prop.I, bn=nn.substr(nn.length-1),scr=nn.substr(2,nn.length-2-bn.length),blk=scr+sep+bn;
					   j[blk]=_createIfNotExist(j[blk]);
					   return j[blk];                     
                };
                function _creatArray(o,n,t){
                               if(!o){
                                               o=[]
                               }
                               while(o.length<=n){
                                               if(t){
                                                               o.push([])
                                               }else{
                                                               o.push({})
                                               }
                               }
                               return o
                };
                function _setAttribute(o,prop,n,attr,num){
                               var s=n[attr];
                               if(s!=undefined && o) {
                                               if(o) {
                                               o[prop]=(num)?parseInt(s,10):s
                                             }
                               }
                };
                //TODO :  align : left middle right from X3 format
                function _setAttributesGuimod(j,n){
                               _setAttribute(j,"stt",n,"s",true);
                               _setAttribute(j,"fmt",n,"f");
                               _setAttribute(j,"sty",n,"style");              
                               _setAttribute(j,"tit",n,"t");  
							   if(n["desabled_choices"]){
                            	   var a=n["desabled_choices"].split(","),b=[];
								   a.forEach(function(c){
										b.push(parseInt(c,10));
								   })
								   j.dch=b;
                               }
                }
                function _createIfNotExist(o){
                               if(!o){
                                   o={}
                               }
                               return o;
                }
                return reply;
}