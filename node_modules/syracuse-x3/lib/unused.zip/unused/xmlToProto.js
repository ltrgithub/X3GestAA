"use strict";

var jsxml = require("jsxml/lib/jsxmlold");

function assert(cond, msg){
    if (!cond) 
        throw new Error(msg)
}

exports.parse = function(str){
    var root = jsxml.parse(str);
    assert(root && root.$$tag === 'WIND');
    var proto = {
        $type: "application/json",
        $url: "http://placeholder",
        $title: root.C,
        $description: root.C,
        $properties: {},
        $article: {
            $layout: {
                $items: [],
            },
            $XID: 0,
            $isFusion: true
        },
        $links: {},
        $X3: doAtbs(root),
    };
    assert(root.$$children);
    
    function colWidths(children){
        if (!children) 
            return '';
        var total = children.reduce(function(val, child){
            return val + (child.NCO || 0);
        }, 0) ||
        1;
        return children.map(function(child){
            return Math.round((child.NCO || 0) * 100 / total);
        }).join(',');
    }
    
    function wrap(article, child){
        return article.$layoutType === 'columns' ? {
            $layoutType: "stack",
            $items: [child]
        } : child;
    }
    
    function container(category, atbs, forLinks){
        return function(n, article){
            var xid = article.$XID + (n.XID || 0);
            var art = {
                $title: n.C,
                $X3: doAtbs(n),
                $XID: xid,
                $isFusion: true
            };
            atbs &&
            Object.keys(atbs).forEach(function(key){
                art[key] = atbs[key];
            })
            if (!category) {
                art.$layoutType = "stack";
                art.$items = [];
            }
            else {
                art.$category = category;
                art.$layout = {
                    $items: []
                };
            }
            if (art.$layoutType === 'columns') 
                art.$widths = colWidths(n.$$children);
            forLinks || (article.$items || article.$layout.$items).push(wrap(article, art));
            doChildren(art, n.$$children);
        }
    }
    
    function cvtType(n){
        switch (n.TYP) {
            case '6':
            case '7':
                return 'application/x-string';
            case '11':
                return n.MNU == '1' ? 'application/x-boolean' : 'application/x-choice';
            case '17':
                return 'image';
            default:
                n.TYP && console.log(n.C + ": unknown type: " + n.TYP);
                return 'application/x-string';
        }
    }
    
    function widget(tag, type){
        return function(n, article){
            assert(!n.$$children);
            assert(n.XID > 0);
            var xid = n.XID + article.$XID;
            var key = tag + xid;
            var items = article.$items || article.$layout.$items;
            items.push(wrap(article, {
                $isEditMode: true,
                $isFusion: true,
                $bind: key,
                $X3: doAtbs(n),
            }));
            assert(!proto.$properties[key]);
            proto.$properties[key] = {
                $title: n.C,
                $type: cvtType(n)
                //$type: type || 'application/x3-' + n.TYP,
            }
        }
    }
    var converters = {
        FOL: container('section'),
        SCRN: container(null),
        LBL: container(null),
        FRM: container('block'),
        GFO: container(null, {
            $layoutType: 'tabs'
        }),
        LIG: container(null, {
            $layoutType: 'columns'
        }),
        ARE: container(null),
        ARG: container(null),
        GRD: function(n, article){
            assert(n.$$children);
            assert(n.XID > 0);
            var xid = n.XID + article.$XID;
            var key = "GRD" + xid;
            var items = article.$items || article.$layout.$items;
            items.push(wrap(article, {
                $isEditMode: true,
                $isFusion: true,
                $bind: key,
                $X3: doAtbs(n),
            }));
            assert(!proto.$properties[key]);
            proto.$properties[key] = {
                $title: n.C,
                $type: "application/x-array",
                $item: {
                    $properties: {}
                }
            }
            var cols = proto.$properties[key].$item.$properties;
            n.$$children.forEach(function(gco){
                assert(gco.$$tag === 'GCO');
                var gcoXID = xid + gco.XID;
                var gcoKey = "GCO" + gcoXID;
                cols[gcoKey] = {
                    $title: gco.C,
                    $type: cvtType(gco)
                }
            });
        },
        MAW: container(null, null, true),
        CAP: widget('CAP', 'application/x3-caption'),
        FLD: widget('FLD'),
        GCO: widget('GCO'),
        EMP: function(n, article){
            assert(!n.$$children);
            assert(!n.XID);
            return; // renderer fails if no $bind
            (article.$items || article.$layout.$items).push({
                $X3: doAtbs(n),
            });
        },
        DATS: function(n, article){
            assert(!article.$X3DATS);
            article.$X3DATS = doMisc(n);
            return null;
        },
        STYL: function(n, article){
            assert(!article.$X3STYL);
            article.$X3STYL = doMisc(n);
            return null;
        },
        BOU: function(n, article){
            proto.$links['L' + n.XID] = {
                $title: n.C,
                $X3: doAtbs(n)
            };
        },
        ITM: function(n, article){
            proto.$links['L' + n.XID] = {
                $title: n.C,
                $X3: doAtbs(n)
            };
        },
    };
    
    function doAtbs(atbs){
        return "..."; // && atbs;
    }
    
    function doMisc(n){
        return "..."; // && n;
    }
    
    function doChildren(article, children){
        var items
        children &&
        children.forEach(function(child){
            var cvt = converters[child.$$tag];
            var art = cvt ? cvt(child, article) : (console.log(child.$$tag), '<' + child.$$tag + '>');
        });
        return article;
    }
    doChildren(proto.$article, root.$$children);
    return proto;
}
