"use strict";

var siteFactory = require('syracuse-ui/lib/site/site');
exports.main = function() {
	siteFactory.load({
		$maxBookmarks: 25,
		$device: "desktop",
		$iconPath: "/syracuse-ui/themes/desktop/sage/images/",
		$userProfileUrl: "/action/user-profile",
	}, {
		$helpLinks: [],
		$links: {
			$home: {
				$title: "Home",
				$url: "/page/home?representation=home.$page"
			},
		},
		$navigation: {			
			$dashboard: {}
		},
		$properties: {}
	});
};
if (require.main == module)
	exports.main();