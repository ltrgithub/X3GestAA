"use strict";
var fs = require('fs');

// streamline cache
try {
	if (!fs.existsSync('licensetool')) fs.mkdirSync('licensetool');
	if (!fs.existsSync('licensetool/cache')) fs.mkdirSync('licensetool/cache');
} catch (e) {
	console.error(e);
}
var cache = "licensetool/cache/" + (process.env.USER || process.env.USERNAME || "");

require('streamline').register({
	"fibers": true,
	"fast": true,
	"cache": true,
	"verbose": true,
	"cacheDir": cache});

require('license-tool/lib/main');